 * COMP 3190 SECTION [A01]
 * INSTRUCTOR: [John Braico]
 * NAME: [Jeremy Arde]
 * ASSIGNMENT: [Assignment 1]
 * QUESTION: [question 2]

NOTES: Question marks sometimes appear when printing out the final solution. 